package com.example.demo11111;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo11111ApplicationTests {

	@Test
	void contextLoads() {
	}

}
